//
// Copyright (C) 2023 Quan Chen <chenquan_act@163.com>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// Derived from medict (https://github.com/terasum/medict),
// internal/libs/go-mdict.
//
// Modified in 2026 by glowinthedark for wudict: v3 fields and the record-
// index types added.
//
// SPDX-License-Identifier: GPL-3.0-or-later

package go_mdict

import "sync"

type MdictType int

const (
	MdictTypeMdd MdictType = 1
	MdictTypeMdx MdictType = 2

	// The header's Encrypted attribute is a bit set (MDict reads it with atoi):
	// bit 0 is a registered dictionary, readable only with the purchaser's
	// registration code; bit 1 is an encrypted key-block info, whose key is in
	// the file.
	EncryptNoEnc      = 0
	EncryptRecordEnc  = 1
	EncryptKeyInfoEnc = 2
	NumfmtBe8bytesq   = 0
	NumfmtBe4bytesi   = 1
	EncodingUtf8      = 0
	EncodingUtf16     = 1
	EncodingBig5      = 2
	ENCODING_GBK      = 3
	ENCODING_GB2312   = 4
	EncodingGb18030   = 5
	EncodingLatin1    = 6
)

// Record content types, from the header's Format (v1/v2) or ContentType (v3).
const (
	ContentText   = 0
	ContentHTML   = 1
	ContentXML    = 2
	ContentBinary = 3
)

type MdictBase struct {
	filePath string
	fileType MdictType
	meta     *mdictMeta

	header       *mdictHeader
	keyBlockMeta *mdictKeyBlockMeta
	keyBlockInfo *mdictKeyBlockInfo
	keyBlockData *mdictKeyBlockData

	recordBlockMeta *mdictRecordBlockMeta
	recordBlockInfo *mdictRecordBlockInfo
	//RecordBlockData *MDictRecordBlockData

	// decompressed record-block cache (bounded FIFO): adjacent headword
	// lookups and inline resources usually share a record block, so caching
	// the decompressed block skips the dominant re-open + re-decompress cost.
	blkMu    sync.Mutex
	blkCache map[int64][]byte // record-block start offset -> decompressed block
	blkOrder []int64          // FIFO eviction order

	// v3 record-block table. v1/v2 get theirs from readRecordBlockInfo, which
	// the format hands them; v3 has no such section to read, so the table is
	// derived by walking the block chain once (recordBlockTableV3) and then
	// binary-searched. nil until built.
	v3RecMu     sync.Mutex
	v3RecBlocks []v3RecordBlock
}

/********************************
 *    private data type          *
 ********************************/
type mdictHeader struct {
	headerBytesSize          uint32
	headerInfoBytes          []byte
	headerInfo               string
	adler32Checksum          uint32
	dictionaryHeaderByteSize int64
}

type mdictMeta struct {
	encryptType  int
	version      float32
	numberWidth  int
	numberFormat int
	encoding     int // record text (v3: RecordData@encoding)
	keyEncoding  int // key text (v3: KeyData@encoding); equal to encoding in v1/v2
	contentType  int // ContentText … ContentBinary
	compact      bool

	// key-block part bytes start offset in the mdx/mdd file
	keyBlockMetaStartOffset int64

	description              string
	title                    string
	creationDate             string
	generatedByEngineVersion string
	stylesheet               string
	headerAttrs              [][2]string

	// v3-only fields
	uuid         string
	encryptedKey []byte          // derived from UUID for v3 encrypted blocks; nil otherwise
	v3Offsets    *v3BlockOffsets // the v3 sections (nil for v1/v2)
}

type mdictKeyBlockMeta struct {
	// keyBlockNum key block number size
	keyBlockNum int64
	// entriesNums entries number size
	entriesNum int64
	// key-block information size (decompressed)
	keyBlockInfoDecompressSize int64
	// key-block information size (compressed)
	keyBlockInfoCompressedSize int64
	// key-block Data Size (decompressed)
	keyBlockDataTotalSize int64
	// key-block information start position in the mdx/mdd file
	keyBlockInfoStartOffset int64
}

type mdictKeyBlockInfo struct {
	keyBlockEntriesStartOffset int64
	keyBlockInfoList           []*mdictKeyBlockInfoItem
}

type mdictKeyBlockInfoItem struct {
	entries                       int64 // keys in the block, as declared
	keyBlockCompressSize          int64
	keyBlockDeCompressSize        int64
	keyBlockDeCompressAccumulator int64
}

type mdictKeyBlockData struct {
	keyEntries                 []*MDictKeywordEntry
	keyEntriesSize             int64
	recordBlockMetaStartOffset int64
}

type mdictRecordBlockMeta struct {
	keyRecordMetaStartOffset int64
	keyRecordMetaEndOffset   int64

	recordBlockNum          int64
	entriesNum              int64
	recordBlockInfoCompSize int64
	recordBlockCompSize     int64
}
type mdictRecordBlockInfo struct {
	recordInfoList             []*MdictRecordBlockInfoListItem
	recordBlockInfoStartOffset int64
	recordBlockInfoEndOffset   int64
	recordBlockDataStartOffset int64
}

type MdictRecordBlockInfoListItem struct {
	compressSize                int64
	deCompressSize              int64
	compressAccumulatorOffset   int64
	deCompressAccumulatorOffset int64
}

/********************************
 *    public data type          *
 ********************************/

type MDictKeywordEntry struct {
	RecordStartOffset int64
	RecordEndOffset   int64
	KeyWord           string
}
