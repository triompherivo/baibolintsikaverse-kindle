// Copyright (C) 2026 glowinthedark
// SPDX-License-Identifier: GPL-3.0-or-later
package bgl
import ("io"; "path"; "strings"; "github.com/wuweidict/wudict/internal/dict"; "github.com/wuweidict/wudict/internal/resource")
// Embedded is the resources a BGL file carries inside it, read into memory by
// one pass over the file. It is a resource.Source, and reading it opens no
// dictionary and prepares nothing: `wudict dump` writes a BGL's resources
// through it.
type Embedded struct {
	data  map[string][]byte // by lowercased name
	names []string          // sorted, in the file's spelling
}

var _ resource.Source = (*Embedded)(nil)

// ReadEmbedded reads the resources embedded in the BGL file at path.
func ReadEmbedded(path string) (*Embedded, error) {
	data, names, err := scanResources(path)
	if err != nil {
		return nil, err
	}
	return &Embedded{data: data, names: names}, nil
}

// Open returns one resource by name, case-insensitively, or dict.ErrNotFound.
func (e *Embedded) Open(name string) (io.ReadCloser, error) {
	norm := strings.ToLower(strings.TrimLeft(path.Clean(name), "/"))
	if norm == "" || norm == "." || strings.HasPrefix(norm, "..") {
		return nil, dict.ErrNotFound
	}
	if b, ok := e.data[norm]; ok {
		return resource.Bytes(b), nil
	}
	return nil, dict.ErrNotFound
}

// List returns the resource names, sorted.
func (e *Embedded) List() []string { return append([]string(nil), e.names...) }

func (e *Embedded) Close() error { return nil }
