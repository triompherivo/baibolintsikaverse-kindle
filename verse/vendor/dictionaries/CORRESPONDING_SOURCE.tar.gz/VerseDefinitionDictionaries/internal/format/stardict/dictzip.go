// Copyright (C) 2026 glowinthedark
//
// SPDX-License-Identifier: GPL-3.0-or-later

package stardict

import (
	"bytes"
	"compress/flate"
	"encoding/binary"
	"fmt"
	"io"
	"sync"
)

// dzReader provides random access into a dictzip (.dict.dz) file: a gzip
// member whose FEXTRA 'RA' subfield lists the compressed size of each
// fixed-length chunk, letting any (offset,size) range be served by
// inflating only the chunks that cover it.
type dzReader struct {
	ra        io.ReaderAt
	chunkLen  int     // uncompressed bytes per chunk
	offsets   []int64 // absolute offset of each compressed chunk
	sizes     []int   // compressed size of each chunk
	mu        sync.Mutex
	cache     map[int][]byte // chunk index -> decompressed bytes
	cacheKeys []int
}

const dzCacheSize = 8

// newDzReader parses the gzip/dictzip header of ra.
func newDzReader(ra io.ReaderAt, fileSize int64) (*dzReader, error) {
	head := make([]byte, min(int(fileSize), 1<<16))
	if _, err := ra.ReadAt(head, 0); err != nil && err != io.EOF {
		return nil, err
	}
	if len(head) < 12 || head[0] != 0x1f || head[1] != 0x8b {
		return nil, fmt.Errorf("not a gzip file")
	}
	if head[2] != 8 {
		return nil, fmt.Errorf("unsupported gzip method %d", head[2])
	}
	flg := head[3]
	if flg&0x04 == 0 { // FEXTRA
		return nil, fmt.Errorf("gzip file lacks dictzip extra field")
	}
	pos := 10
	if pos+2 > len(head) {
		return nil, fmt.Errorf("truncated gzip header")
	}
	xlen := int(binary.LittleEndian.Uint16(head[pos:]))
	pos += 2
	// head is at most 64 KiB and may be far shorter (it is min(fileSize, 64K)),
	// while XLEN is a u16 that can name 65535 bytes regardless. Slicing one by
	// the other panics on a truncated file.
	if pos+xlen > len(head) {
		return nil, fmt.Errorf("FEXTRA field of %d bytes exceeds the %d-byte header", xlen, len(head))
	}
	extra := head[pos : pos+xlen]
	pos += xlen

	d := &dzReader{ra: ra, cache: map[int][]byte{}}
	found := false
	for len(extra) >= 4 {
		si1, si2 := extra[0], extra[1]
		slen := int(binary.LittleEndian.Uint16(extra[2:]))
		// The loop guard is len(extra) >= 4, which bounds si1/si2/slen and not
		// the subfield those describe. SLEN is clamped rather than rejected:
		// writers exist whose RA subfield declares two bytes more than XLEN
		// left for it (one chunk-table slot too many), and XLEN - not SLEN -
		// is what the rest of the gzip header is positioned by, so the field
		// truly ends where XLEN says. Walking past it panicked on
		// `extra[4+slen:]`, because the reslice is bounded by cap (the whole
		// 64 KiB header buffer) and only len(extra) makes 4+slen illegal.
		if slen > len(extra)-4 {
			slen = len(extra) - 4
		}
		sub := extra[4 : 4+slen]
		if si1 == 'R' && si2 == 'A' {
			// RA layout: version u16, chunk length u16, chunk count u16, then
			// one u16 per chunk.
			if len(sub) < 6 {
				return nil, fmt.Errorf("dictzip RA field truncated (%d bytes)", len(sub))
			}
			ver := binary.LittleEndian.Uint16(sub[0:])
			if ver != 1 {
				return nil, fmt.Errorf("unsupported dictzip version %d", ver)
			}
			d.chunkLen = int(binary.LittleEndian.Uint16(sub[2:]))
			chcnt := int(binary.LittleEndian.Uint16(sub[4:]))
			// Same truncation, one level down: the count is read out of the
			// subfield and then indexes it, so it is bounded by the bytes
			// actually present. A table cut short costs the articles in the
			// chunks it no longer names, not the dictionary.
			if avail := (len(sub) - 6) / 2; chcnt > avail {
				chcnt = avail
			}
			if chcnt == 0 {
				return nil, fmt.Errorf("dictzip RA lists no chunks")
			}
			d.sizes = make([]int, chcnt)
			for i := 0; i < chcnt; i++ {
				d.sizes[i] = int(binary.LittleEndian.Uint16(sub[6+2*i:]))
			}
			found = true
		}
		extra = extra[4+slen:]
	}
	if !found || d.chunkLen == 0 {
		return nil, fmt.Errorf("dictzip RA field missing or empty")
	}
	if flg&0x08 != 0 { // FNAME: NUL-terminated
		for pos < len(head) && head[pos] != 0 {
			pos++
		}
		pos++
	}
	if flg&0x10 != 0 { // FCOMMENT
		for pos < len(head) && head[pos] != 0 {
			pos++
		}
		pos++
	}
	if flg&0x02 != 0 { // FHCRC
		pos += 2
	}
	d.offsets = make([]int64, len(d.sizes))
	off := int64(pos)
	for i, sz := range d.sizes {
		d.offsets[i] = off
		off += int64(sz)
	}
	return d, nil
}

// readRange returns size uncompressed bytes starting at offset.
func (d *dzReader) readRange(offset int64, size int) ([]byte, error) {
	if size == 0 {
		return nil, nil
	}
	// (offset,size) is a u32 pair straight out of the .idx. size is widened to
	// int, which is negative on a 32-bit build for anything past 2 GiB; a
	// corrupt index must cost one article, not a slice-bounds panic in a
	// fan-out worker - and must not send the chunk loop inflating every chunk
	// to the end of the file into one buffer, which an oversized size did.
	if offset < 0 || size < 0 {
		return nil, fmt.Errorf("record range out of bounds (offset %d, %d bytes)", offset, size)
	}
	// The uncompressed extent is at most chunk count × chunk length (only the
	// last chunk is short). A range reaching past that names bytes the file
	// cannot contain; refusing it here is what keeps `last` inside the chunks
	// the range actually covers.
	if offset+int64(size) > int64(len(d.offsets))*int64(d.chunkLen) {
		return nil, io.ErrUnexpectedEOF
	}
	first := offset / int64(d.chunkLen)
	last := (offset + int64(size) - 1) / int64(d.chunkLen)
	if first >= int64(len(d.offsets)) {
		return nil, io.ErrUnexpectedEOF
	}
	var buf bytes.Buffer
	for i := first; i <= last; i++ {
		chunk, err := d.chunk(int(i))
		if err != nil {
			return nil, err
		}
		buf.Write(chunk)
	}
	start := offset - first*int64(d.chunkLen)
	if start+int64(size) > int64(buf.Len()) {
		return nil, io.ErrUnexpectedEOF
	}
	return buf.Bytes()[start : start+int64(size)], nil
}

// chunk inflates one chunk (dictzip chunks start at deflate full-flush
// boundaries, so each is independently decompressible).
func (d *dzReader) chunk(i int) ([]byte, error) {
	d.mu.Lock()
	if c, ok := d.cache[i]; ok {
		d.mu.Unlock()
		return c, nil
	}
	d.mu.Unlock()

	comp := make([]byte, d.sizes[i])
	if _, err := d.ra.ReadAt(comp, d.offsets[i]); err != nil && err != io.EOF {
		return nil, err
	}
	fr := flate.NewReader(bytes.NewReader(comp))
	out := make([]byte, d.chunkLen)
	n, err := io.ReadFull(fr, out)
	// the final chunk is shorter; a chunk stream may also end without a
	// terminating block - both surface as EOF errors after valid data
	if err != nil && n == 0 {
		return nil, fmt.Errorf("dictzip chunk %d: %w", i, err)
	}
	out = out[:n]

	d.mu.Lock()
	// Two readers can inflate the same chunk at once; only the first insert
	// joins the FIFO, or its key would sit in it twice and the second
	// eviction would drop a later, still-fresh copy.
	if _, dup := d.cache[i]; !dup {
		d.cacheKeys = append(d.cacheKeys, i)
	}
	d.cache[i] = out
	if len(d.cacheKeys) > dzCacheSize {
		delete(d.cache, d.cacheKeys[0])
		d.cacheKeys = d.cacheKeys[1:]
	}
	d.mu.Unlock()
	return out, nil
}
