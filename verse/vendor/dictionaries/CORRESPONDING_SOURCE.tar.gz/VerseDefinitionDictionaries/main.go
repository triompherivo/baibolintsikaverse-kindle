// Original WASI adapter for the separately acquired GPL-3.0 WuDict parsers.
// Files live in a browser worker's in-memory WASI filesystem; no network or
// access to the user's real filesystem is provided to this converter.
package main

import (
 "archive/zip"
 "encoding/json"
 "fmt"
 "io"
 "mime"
 "os"
 "path/filepath"
 "strings"

 "github.com/bodgit/sevenzip"
 "github.com/wuweidict/wudict/internal/dict"
 "github.com/wuweidict/wudict/internal/format/bgl"
 "github.com/wuweidict/wudict/internal/format/dsl"
 "github.com/wuweidict/wudict/internal/format/mdx"
 "github.com/wuweidict/wudict/internal/format/slob"
 "github.com/wuweidict/wudict/internal/format/stardict"
 "github.com/wuweidict/wudict/internal/format/zim"
)

const maxBytes = 256 << 20
type Entry struct { Term string `json:"term"`; Definition string `json:"definition"`; HTML string `json:"html,omitempty"`; Link string `json:"link,omitempty"` }
type Resource struct { MIME string `json:"mime"`; Data []byte `json:"data"` }
type Result struct { Name string `json:"name"`; Format string `json:"format"`; Entries []Entry `json:"entries"`; Resources map[string]Resource `json:"resources,omitempty"`; Error string `json:"error,omitempty"` }
func fail(err error) { _ = json.NewEncoder(os.Stdout).Encode(Result{Error:err.Error()}) }
func safeMember(root, name string) (string,error) {
 if strings.Contains(name,"\\") || strings.HasPrefix(name,"/") { return "",fmt.Errorf("unsafe archive pathname") }
 for _,part:=range strings.Split(name,"/") { if part==".." {return "",fmt.Errorf("unsafe archive traversal")} }
 return filepath.Join(root,name),nil
}
func extract(archive string) (string,error) {
 root:=archive+".extracted";if err:=os.MkdirAll(root,0700);err!=nil{return "",err};total:=int64(0);count:=0
 write:=func(name string,isDir bool,open func()(io.ReadCloser,error))error {
  count++;if count>10000{return fmt.Errorf("too many archive entries")};p,err:=safeMember(root,name);if err!=nil{return err};if isDir{return os.MkdirAll(p,0700)}
  if err=os.MkdirAll(filepath.Dir(p),0700);err!=nil{return err};in,err:=open();if err!=nil{return err};defer in.Close();out,err:=os.Create(p);if err!=nil{return err};defer out.Close();n,err:=io.Copy(out,io.LimitReader(in,maxBytes-total+1));total+=n;if total>maxBytes{return fmt.Errorf("archive exceeds 256 MiB")};return err
 }
 if strings.HasSuffix(strings.ToLower(archive),".7z") { r,err:=sevenzip.OpenReader(archive);if err!=nil{return "",err};defer r.Close();for _,f:=range r.File{if err=write(f.Name,f.FileInfo().IsDir(),f.Open);err!=nil{return "",err}} } else {
  r,err:=zip.OpenReader(archive);if err!=nil{return "",err};defer r.Close();for _,f:=range r.File{if f.Mode()&os.ModeSymlink!=0{return "",fmt.Errorf("archive symlinks not supported")};if err=write(f.Name,f.FileInfo().IsDir(),f.Open);err!=nil{return "",err}}
 }
 return root,nil
}
func choose(root string)(string,error){
 var found []string
 err:=filepath.WalkDir(root,func(p string,d os.DirEntry,err error)error{if err!=nil{return err};if d.IsDir(){return nil};low:=strings.ToLower(p);for _,ext:=range []string{".ifo",".dsl",".dsl.dz",".mdx",".bgl",".slob",".zim"}{if strings.HasSuffix(low,ext){found=append(found,p);break}};return nil})
 if err!=nil{return "",err};if len(found)!=1{return "",fmt.Errorf("choose one dictionary package (found %d)",len(found))};return found[0],nil
}
func open(path string)(dict.Reader,error){
 low:=strings.ToLower(path)
 switch {case strings.HasSuffix(low,".ifo"):return stardict.NewReader(path);case strings.HasSuffix(low,".dsl"),strings.HasSuffix(low,".dsl.dz"):return dsl.NewReader(path);case strings.HasSuffix(low,".bgl"):return bgl.NewReader(path);case strings.HasSuffix(low,".mdx"):return mdx.NewReader(path);case strings.HasSuffix(low,".slob"):return slob.NewReader(path);case strings.HasSuffix(low,".zim"):return zim.NewReader(path)}
 return nil,fmt.Errorf("unsupported dictionary package")
}
func resourceData(path string)(map[string]Resource,error){
 type source interface {Resources()[]string;Resource(string)(io.ReadCloser,string,error);Close()error}
 var s source;var err error
 switch strings.ToLower(filepath.Ext(path)){case ".mdx":s,err=mdx.Open(path);case ".ifo":s,err=stardict.Open(path);case ".slob":s,err=slob.Open(path);case ".zim":s,err=zim.Open(path)}
 result:=map[string]Resource{};if err!=nil{return nil,err};total:=0
 add:=func(name,m string,r io.ReadCloser)error{defer r.Close();data,e:=io.ReadAll(io.LimitReader(r,maxBytes-int64(total)+1));if e!=nil{return e};total+=len(data);if total>maxBytes{return fmt.Errorf("dictionary resources exceed 256 MiB")};if m==""{m=mime.TypeByExtension(filepath.Ext(name))};result[name]=Resource{MIME:m,Data:data};return nil}
 if s!=nil {defer s.Close();for _,name:=range s.Resources(){r,m,e:=s.Resource(name);if e!=nil{return nil,e};if e=add(name,m,r);e!=nil{return nil,e}}}
 if strings.HasSuffix(strings.ToLower(path),".bgl"){b,e:=bgl.ReadEmbedded(path);if e!=nil{return nil,e};defer b.Close();for _,name:=range b.List(){r,e:=b.Open(name);if e!=nil{return nil,e};if e=add(name,"",r);e!=nil{return nil,e}}}
 return result,nil
}
func glossaryText(value any)string{switch v:=value.(type){case string:return v;case []any:var items []string;for _,item:=range v{items=append(items,glossaryText(item))};return strings.Join(items,"\n");case map[string]any:if s,ok:=v["content"];ok{return glossaryText(s)};if s,ok:=v["text"];ok{return glossaryText(s)};if s,ok:=v["alt"];ok{return glossaryText(s)}};return ""}
func yomitan(root string)(*Result,error){
 var index string;var banks []string
 err:=filepath.WalkDir(root,func(p string,d os.DirEntry,e error)error{if e!=nil{return e};if d.IsDir(){return nil};name:=filepath.Base(p);if name=="index.json"{index=p};if strings.HasPrefix(name,"term_bank_")&&strings.HasSuffix(name,".json"){banks=append(banks,p)};return nil});if err!=nil{return nil,err};if index==""||len(banks)==0{return nil,nil}
 data,err:=os.ReadFile(index);if err!=nil{return nil,err};var meta map[string]any;if err=json.Unmarshal(data,&meta);err!=nil{return nil,err};name,_:=meta["title"].(string);result:=&Result{Name:name,Format:"yomitan",Entries:[]Entry{}}
 for _,bank:=range banks{data,e:=os.ReadFile(bank);if e!=nil{return nil,e};var rows [][]any;if e=json.Unmarshal(data,&rows);e!=nil{return nil,e};for _,row:=range rows{if len(row)<6{return nil,fmt.Errorf("invalid Yomitan bank row")};term,ok:=row[0].(string);if !ok{return nil,fmt.Errorf("invalid Yomitan headword")};result.Entries=append(result.Entries,Entry{Term:term,Definition:glossaryText(row[5])});if reading,ok:=row[1].(string);ok&&reading!=""&&reading!=term{result.Entries=append(result.Entries,Entry{Term:reading,Definition:glossaryText(row[5])})}}}
 return result,nil
}
func main(){
 if len(os.Args)<2{fail(fmt.Errorf("dictionary pathname required"));return};path:=os.Args[1]
 if info,err:=os.Stat(path);err==nil&&info.IsDir(){if result,e:=yomitan(path);e!=nil{fail(e);return}else if result!=nil{_ = json.NewEncoder(os.Stdout).Encode(result);return};path,err=choose(path);if err!=nil{fail(err);return}}else if strings.HasSuffix(strings.ToLower(path),".zip")||strings.HasSuffix(strings.ToLower(path),".7z"){root,e:=extract(path);if e!=nil{fail(e);return};if result,e:=yomitan(root);e!=nil{fail(e);return}else if result!=nil{_ = json.NewEncoder(os.Stdout).Encode(result);return};path,e=choose(root);if e!=nil{fail(e);return}}
 reader,err:=open(path);if err!=nil{fail(err);return};defer reader.Close();meta:=reader.Meta();result:=Result{Name:meta.Name,Format:meta.Format,Entries:[]Entry{}};size:=0
 for {entry,e:=reader.Next();if e==io.EOF{break};if e!=nil{fail(e);return};size+=len(entry.Body);if size>maxBytes||len(result.Entries)>1000000{fail(fmt.Errorf("dictionary exceeds browser conversion limit"));return};for _,word:=range entry.Headwords{r:=Entry{Term:word,Definition:entry.Body,Link:entry.LinkTo};if entry.Kind==dict.BodyHTML{r.HTML=entry.Body};result.Entries=append(result.Entries,r)}}
 result.Resources,err=resourceData(path);if err!=nil{fail(err);return};_=json.NewEncoder(os.Stdout).Encode(result)
}
