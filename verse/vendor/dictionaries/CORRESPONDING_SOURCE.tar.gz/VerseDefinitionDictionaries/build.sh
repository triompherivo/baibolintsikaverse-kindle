#!/bin/sh
set -eu
cd "$(dirname "$0")"
output=${1:?Indiquer le répertoire vendor/dictionaries de destination}
mkdir -p "$output"
GO=${GO:-go}
export GOTOOLCHAIN=local GOOS=wasip1 GOARCH=wasm CGO_ENABLED=0
trap 'rm -f "$output/dictionaries.wasm.tmp"' EXIT HUP INT TERM
"$GO" build -mod=vendor -trimpath -ldflags='-s -w' -o "$output/dictionaries.wasm.tmp" .
mv "$output/dictionaries.wasm.tmp" "$output/dictionaries.wasm"
cp LICENSE THIRD-PARTY-NOTICES.md "$output/"
python3 - "$output" <<'PY'
import gzip,io,tarfile,sys
from pathlib import Path
root=Path.cwd(); output=Path(sys.argv[1]).resolve()
with (output/'CORRESPONDING_SOURCE.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for path in sorted(root.rglob('*')):
    if not path.is_file() or any(part.startswith('.') for part in path.relative_to(root).parts): continue
    data=path.read_bytes(); info=tarfile.TarInfo('VerseDefinitionDictionaries/'+path.relative_to(root).as_posix())
    info.size=len(data);info.mtime=0;info.mode=0o755 if path.name=='build.sh' else 0o644
    archive.addfile(info,io.BytesIO(data))
(output/'README.md').write_bytes((root/'README.md').read_bytes())
PY
