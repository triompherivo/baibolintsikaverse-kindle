module github.com/wuweidict/wudict

go 1.26.5

require (
	github.com/anchore/go-lzo v0.1.1
	github.com/bodgit/sevenzip v1.6.5
	github.com/c0mm4nd/go-ripemd v0.0.0-20200326052756-bd1759ad7d10
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/klauspost/compress v1.19.0
	github.com/pierrec/lz4/v4 v4.1.27
	github.com/ulikunitz/xz v0.5.16
	golang.org/x/net v0.57.0
	golang.org/x/text v0.40.0
)

require (
	github.com/andybalholm/brotli v1.2.2 // indirect
	github.com/bodgit/plumbing v1.3.0 // indirect
	github.com/bodgit/windows v1.0.1 // indirect
	github.com/hashicorp/golang-lru/v2 v2.0.7 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/stangelandcl/ppmd v0.1.1 // indirect
	go4.org v0.0.0-20260112195520-a5071408f32f // indirect
)
